import React, { useState, useEffect } from "react";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
import Home from "./component/Home";
import Form from "./component/Form";
import NavigationBar from "./component/NavigationBar";
import "bootstrap/dist/css/bootstrap.min.css";
import Page404 from "./component/404";
const App = () => {
  const initial_stateOrderRecord = null;
  const [stateOrderRecord, set_OrderRecord] = useState(
    initial_stateOrderRecord
  );
  const [array_of_OrderRecord, set_array_of_OrderRecord] = useState([]);

  useEffect(() => {
    stateOrderRecord &&
      set_array_of_OrderRecord([...array_of_OrderRecord, stateOrderRecord]);
    set_OrderRecord(initial_stateOrderRecord);
  }, [stateOrderRecord]);

  useEffect(() => {
    console.log(
      "Array.from(array_of_OrderRecord).length = ",
      Array.from(array_of_OrderRecord).length
    );
    console.log(
      "Array.from(array_of_OrderRecord).length = ",
      Array.from(array_of_OrderRecord).length
    );
  });

  return (
    <main>
      <h1>Lambda Eats</h1>

      <NavigationBar />

      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/pizza">
            <Form input_cb_set_OrderRecord={set_OrderRecord} />
          </Route>
          <Route component={Page404} />
        </Switch>
      </BrowserRouter>
    </main>
  );
};
export default App;
