import React from "react";
import Home from "./component/Home";
const App = () => {
  return (
    <>
      <h1>Lambda Eats</h1>
      <Home />
    </>
  );
};
export default App;
