import React, { useState, useEffect } from "react";
import { toppings, sauces, pizzaSize } from "./constant";

export default function Form(props) {
  const initial_state = {
    size: "",
    sauce: sauces[0],
    toppings: [],
    gluten: false,
    specialInstruction: "",
    quantity: "",
  };

  const [stateFormData, set_FormData] = useState(initial_state);

  const cb_onChange = (event) => {
    console.log("event.target = ", event.target);
    console.log("event = ", event);

    let { checked, value, name, type } = event.target;
    let valueToUse = type === "checkbox" ? checked : value;

    if ((event.target.name = "toppings")) {
      let temp_array = stateFormData.toppings;

      checked && temp_array.push(event.target.value);

      !checked &&
        temp_array.filter((element) => {
          return element != value;
        });

      value = temp_array;
    }

    set_FormData({ ...stateFormData, [name]: valueToUse });
  };

  const cb_onSubmit = (event) => {};

  useEffect(() => {
    console.log(stateFormData);
  }, [stateFormData]);

  return (
    <div>
      <h2>Form Page</h2>
      <form onSubmit={cb_onSubmit}>
        <div>
          <label>
            <h3>Choice of Size</h3>
            <p>(validation text)</p>
            <select
              id="size"
              name="size"
              onChange={cb_onChange}
              value={stateFormData.size}
            >
              {pizzaSize.map((element) => {
                return <option value={element}>{element}</option>;
              })}
            </select>
          </label>
        </div>
        <div>
          <h3> Choice of Sauce</h3>
          <p>(validation text)</p>
          <div class="sauce_radio">
            {sauces.map((sauce_name) => {
              return (
                <label>
                  <input
                    name="sauce"
                    id="sauce"
                    onChange={cb_onChange}
                    type="radio"
                    value={sauce_name}
                    checked={
                      stateFormData.sauce.includes(sauce_name) ? true : false
                    }
                  />
                  {sauce_name}
                </label>
              );
            })}
          </div>
        </div>
        <div>
          <h3>Add Toppings</h3>
          <p>(validation text)</p>
          {toppings.map((topping) => {
            return (
              <label>
                <input
                  name="toppings"
                  id="toppings"
                  type="checkbox"
                  value={topping}
                  onChange={cb_onChange}
                />
                {topping}
              </label>
            );
          })}
        </div>
        <div>
          <h3>Choice of Substitute</h3>
          <p>(validation text)</p>
          <label>
            <input
              type="checkbox"
              name="gluten"
              id="gluten"
              onChange={cb_onChange}
            ></input>
          </label>
        </div>
        <div>
          <h3>Special Instructions</h3>
          <p>(validation text)</p>
          <label>
            <input
              id="specialInstruction"
              name="specialInstruction"
              type="text"
              placeholder="Anything else you'd like to add?"
              onChange={cb_onChange}
            ></input>
          </label>
        </div>
        <div>
          <h3>(Final section)</h3>
          <p>(validation text)</p>
          <label>
            <input
              id="quantity"
              name="quantity"
              type="number"
              min="0"
              max="100"
              onChange={cb_onChange}
            ></input>
          </label>
          <button>Add to Order</button>
        </div>
      </form>
    </div>
  ); //end return statement
} //end function

/*

        
            
    if (type === "checkbox") {
      //if box is checked
      if (checked === true) {
        valueToUse = [...toppings, value];
      }

      //if box is unchecked
      if (checked === false) {
        valueToUse = toppings.filter((element) => {
          return element != value;
        });
      }
    } else {
      valueToUse = value;
    }




*/
