import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

export default function Home(props) {
  return (
    <div>
      <h2>Home Page</h2>
      <div>
        <Link href="/pizza">Pizza?</Link>
      </div>
    </div>
  );
}
