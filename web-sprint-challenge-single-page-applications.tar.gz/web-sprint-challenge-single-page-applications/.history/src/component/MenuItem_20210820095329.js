import React from "react";

export default function MenuItem(props) {
  return (
    <div>
      <img src={props.input_object.src} alt="a random image" />
      <h3>{props.input_object.title}</h3>
      <p>$ {props.input_object.description}</p>
      <p>${props.input_object.delievery_fee}</p>
      <p>${props.input_object.dellievery_time</p>
    </div>
  );
}
