import React from "react";
import { toppings, sauces } from "./constant";

export default function Form(props) {
  return (
    <div>
      <h2>Form Page</h2>
      <form>
        <div>
          <label>
            <h3>Choice of Size</h3>
            <br />
            <select>
              <option>Small</option>
              <option>Medium</option>
              <option>Large</option>
              <option>Extra Large</option>
            </select>
          </label>
        </div>
        <div>
          <h3> Choice of Sauce</h3>
          {sauces.map((sauce) => {
            return (
              <label>
                <input type="radio" value={} />
                Original Red
              </label>
            );
          })}
          <br />

          <label>
            <input type="radio" value="" />
            Garlic Ranch
          </label>
          <label>
            <input type="radio" value="" />
            BBQ Sauce
          </label>
          <label>
            <input type="radio" value="" />
            Spinach Alfredo
          </label>
        </div>
        <div>
          <p>Add Toppings</p>
          {toppings.map((topping) => {
            return (
              <label>
                <input type="checkbox" value={topping} />
                {topping}
              </label>
            );
          })}
        </div>
        <div>
          <label>
            Choice of Substitute
            <input type="checkbox"></input>
          </label>
        </div>
        <div>
          <label>
            Special Instructions
            <input type="text"></input>
          </label>
        </div>
        <div>
          <label>
            <input></input>
          </label>
          <button></button>
        </div>
      </form>
    </div>
  );
}
