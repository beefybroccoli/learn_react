import React from "react";

export default function Form(props) {
  return (
    <div>
      <h2>Form Page</h2>
      <form>
        <label>
          Choice of Size
          <select>
            <option>Small</option>
            <option>Medium</option>
            <option>Large</option>
            <option>Extra Large</option>
          </select>
        </label>
        <label>
          Choice of Sauce
          <input type="radio">Original Red</input>
          <input type="radio">Garlic Ranch</input>
          <input type="radio">BBQ Sauce</input>
          <input type="radio">Spinach Alfredo</input>
        </label>
        <label>
          Add Toppings
          <input type="checkbox">Pepperoni</input>
          <input type="checkbox">Sausage</input>
          <input type="checkbox">Can</input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
          <input type="checkbox"></input>
        </label>
        <label>Choice of Substitute</label>
        <label>Special Instructions</label>
        <label></label>
        <button></button>
      </form>
    </div>
  );
}
