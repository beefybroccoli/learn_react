import React from "react"
import Home from "../component/Form"

export default function  Home (props){

    return (
        <div>
            <h2>Home Page</h2>
        </div>
    );
}