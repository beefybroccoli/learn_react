import { Navbar, Nav, Container } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

export default function NavigationBar(props) {
  return (
    <Navbar fixed="top" expand="sm" bg="dark" variant="dark">
      <Container>
        <Navbar.Brand href="/">LAMBDA EATS</Navbar.Brand>
        <Nav className="pull-right">
          <Nav.Link href="/">Home</Nav.Link>
          <Nav.Link to="/pizza">Order</Nav.Link>
          <Nav.Link>Your Order</Nav.Link>
        </Nav>
      </Container>
    </Navbar>
  );
}
