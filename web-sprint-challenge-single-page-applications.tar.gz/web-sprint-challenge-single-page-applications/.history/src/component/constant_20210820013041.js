export const toppings = ["Pepperoni", "Sausage","Canadian Bacon"];
