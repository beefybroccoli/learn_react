export const toppings = [
  "Topping_Pepperoni",
  "Topping_Sausage",
  "Topping_Canadian_Bacon",
  "Topping_Spicy_Italian_Sausage",
  "Topping_Grilled_Chicken",
  "Topping_Onions",
  "Topping_Green_Pepper",
  "Topping_Diced_Tomatos",
  "Topping_Black_Olives",
  "Topping_Roasted_Garlic",
  "Topping_Artichoke_Hearts",
  "Topping_Three_Cheese",
  "Topping_Pineapple",
  "Topping_Extra_Cheese",
];

export const OrderObject = {
  name: "",
  size: "",
  sauce: "",
  glutent: "",
  specialInstruction: "",
  quantity: "",
  Topping_Pepperoni: false,
  Topping_Sausage: false,
  Topping_Canadian_Bacon: false,
  Topping_Spicy_Italian_Sausage: false,
  Topping_Grilled_Chicken: false,
  Topping_Onions: false,
  Topping_Green_Pepper: false,
  Topping_Diced_Tomatos: false,
  Topping_Black_Olives: false,
  Topping_Roasted_Garlic: false,
  Topping_Artichoke_Hearts: false,
  Topping_Three_Cheese: false,
  Topping_Pineapple: false,
  Topping_Extra_Cheese: false,
};

export const sauces = [
  "Original Red",
  "Garlic Ranch",
  "BBQ Sauce",
  "Spinach Alfredo",
];

export const menu_items = [
  {
    title: "McDonald",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Pizza Hut",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Carl's Junior",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Dominos",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Walmart",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Target",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
];

export const pizzaSize = ["Select", "Small", "Medium", "Large", "Extra Large"];

export const API_URL = "https://reqres.in/api/orders";

export const initial_state_formData = {
  name: "",
  size: "Select",
  sauce: sauces[0],
  toppings: [],
  gluten: false,
  specialInstruction: "",
  quantity: "",
};

export const initial_state_error = {
  name: "",
  size: "Select",
  sauce: sauces[0],
  toppings: [],
  gluten: false,
  specialInstruction: "",
  quantity: "",
};


/*
 {title:"",image_src:"" ,image_alt:"", description:"",dellievery_time:"",delievery_fee:""}
*/
