export const toppings = [
  "Pepperoni",
  "Sausage",
  "Canadian Bacon",
  "Spicy Italian Sausage",
  "Grilled Chicken",
  "Onions",
  "Green Pepper",
  "Diced Tomatos",
  "Black Olives",
  "Roasted Garlic",
  "Artichoke Hearts",
  "Three Cheese",
  "Pineapple",
  "Extra Cheese",
];

export const sauces = [
  "Original Red",
  "Garlic Ranch",
  "BBQ Sauce",
  "Spinach Alfredo",
];

export const menu

export const pizzaSize = ["Select", "Small", "Medium", "Large", "Extra Large"];
