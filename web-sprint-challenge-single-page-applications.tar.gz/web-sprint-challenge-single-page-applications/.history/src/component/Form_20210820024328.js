import React, { useState, useEffect } from "react";
import { toppings, sauces, pizzaSize } from "./constant";

export default function Form(props) {
  const initial_state = {
    size: "",
    sauce: "",
    toppings: [],
    gluten: false,
    specialInstruction: "",
    quantity: "",
  };

  const [stateFormData, set_FormData] = useState(initial_state);

  const cb_onChange = (event) => {};

  const cb_onSubmit = (event) => {};

  return (
    <div>
      <h2>Form Page</h2>
      <form onSubmit={cb_onSubmit}>
        <div>
          <label>
            <h3>Choice of Size</h3>
            <p>(validation text)</p>
            <select
              id="size"
              name="size"
              onChange={cb_onChange}
              value={stateFormData.size}
            >
              {pizzaSize.map((element) => {
                return <option value={element}>{element}</option>;
              })}
            </select>
          </label>
        </div>
        <div>
          <h3> Choice of Sauce</h3>
          <p>(validation text)</p>
          <div class="">
            {sauces.map((sauce) => {
              return (
                <label>
                  <input
                    onChange={cb_onChange}
                    type="radio"
                    value={sauce}
                    checked={stateFormData.sauce === sauce}
                  />
                  {sauce}
                </label>
              );
            })}
          </div>
        </div>
        <div>
          <h3>Add Toppings</h3>
          <p>(validation text)</p>
          {toppings.map((topping) => {
            return (
              <label>
                <input type="checkbox" value={topping} />
                {topping}
              </label>
            );
          })}
        </div>
        <div>
          <h3>Choice of Substitute</h3>
          <p>(validation text)</p>
          <label>
            <input type="checkbox" aria-label="Toggle Button"></input>
          </label>
        </div>
        <div>
          <h3>Special Instructions</h3>
          <p>(validation text)</p>
          <label>
            <input
              type="text"
              placeholder="Anything else you'd like to add?"
            ></input>
          </label>
        </div>
        <div>
          <h3>(Final section)</h3>
          <p>(validation text)</p>
          <label>
            <input type="number" min="0" max="100"></input>
          </label>
          <button>Add to Order</button>
        </div>
      </form>
    </div>
  ); //end return statement
} //end function

/*

        
            





*/
