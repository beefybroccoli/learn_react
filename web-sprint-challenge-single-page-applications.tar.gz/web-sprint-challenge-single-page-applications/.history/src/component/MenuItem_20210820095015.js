import React from "react";

export default function MenuItem(props){
    return (
        <div>
            <img src=""/>
            <h3></h3>

        </div>
    );
}