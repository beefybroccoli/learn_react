import React from "react";

export default function Form(props) {
  return (
    <div>
      <h2>Form Page</h2>
      <form>
          <label>Choice of Size</label>
          <label>Choice of Sauce</label>
          <label>Add Toppings</label>
          <label>Choice of Substitute</label>
          <label>Special Instructions</label>
          
      </form>
    </div>
  );
}
