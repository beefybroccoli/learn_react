import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
import App from "../App.css";
import { menu_items } from "../component/constant";
import MenuItem from "./MenuItem";

export default function Home(props) {
  return (
    <div>
      {/* <h2>Home Page</h2> */}
      <div class="home-banner">
        <Link to="/pizza" id="order-pizza">
          Pizza?
        </Link>
      </div>
      <div class="home-menu flex-row flex-wrap">
        <>
          {Array.from(menu_items) &&
            Array.from(menu_items).map((object) => {
              return <MenuItem input_object={object} />;
            })}
        </>
      </div>
    </div>
  );
}
