import React from "react"

export default function  Home (props){

    return (
        <div>
            <h2>Home Page</h2>
        </div>
    );
}