import React, { useState, useEffect } from "react";
import { toppings, sauces, pizzaSize } from "./constant";
import "bootstrap/dist/css/bootstrap.min.css";

export default function Form(props) {
  const initial_state = {
    name: "",
    size: "Select",
    sauce: sauces[0],
    toppings: [],
    gluten: false,
    specialInstruction: "",
    quantity: "",
  };

  const [stateFormData, set_FormData] = useState(initial_state);

  const cb_onChange = (event) => {
    console.log("event.target = ", event.target);
    console.log("event = ", event);

    const { checked, value, name, type } = event.target;
    let valueToUse = type === "checkbox" ? checked : value;

    if (event.target.name === "toppings") {
      let temp_array = Array.from(stateFormData.toppings);
      //if box is checked
      if (checked === true) {
        valueToUse = [...temp_array, value];
      }
      //if box is unchecked
      if (checked === false) {
        valueToUse = temp_array.filter((element) => {
          return element !== value;
        });
      }
    }

    set_FormData({ ...stateFormData, [name]: valueToUse });
  };

  const cb_onSubmit = (event) => {
    event.preventDefault();

    const new_order = {
      name:stateFormData.name,
      size:stateFormData.size,
      sauce:state
    }

  };

  useEffect(() => {
    console.log(stateFormData);
  }, [stateFormData]);

  return (
    <div>
      {/* <h2>Form - Build Your Pizza</h2> */}
      <form onSubmit={cb_onSubmit} id="pizza-form">
        <div>
          <div class="form-group-header">
            <h3>Tell us your name</h3>
            <p>(validation text)</p>
          </div>
          <div class="form-group">
            <label>
              Name:
              <input
                type="text"
                name="name"
                id="name-input"
                onChange={cb_onChange}
                value={stateFormData.name}
                class="form-control"
              />
            </label>
          </div>
        </div>
        <div>
          <div class="form-group-header">
            <h3>Choice of Size</h3>
            <p>(validation text)</p>
          </div>
          <div class="form-group">
            <label class="width-50-percent">
              <select
                id="size-dropdown"
                name="size"
                onChange={cb_onChange}
                value={stateFormData.size}
                class="form-control"
              >
                {pizzaSize.map((element) => {
                  return <option value={element}>{element}</option>;
                })}
              </select>
            </label>
          </div>
        </div>
        <div>
          <div class="form-group-header">
            <h3>Choice of Sauce</h3>
            <p>(validation text)</p>
          </div>

          <div class="form-group sauce_radio flex-column flex-nowrap">
            {sauces.map((sauce_name) => {
              return (
                <label>
                  <input
                    name="sauce"
                    id="sauce"
                    onChange={cb_onChange}
                    type="radio"
                    value={sauce_name}
                    checked={stateFormData.sauce === sauce_name ? true : false}
                    class="form-check-input"
                  />
                  {sauce_name}
                </label>
              );
            })}
          </div>
        </div>
        <div>
          <div class="form-group-header">
            <h3>Add Toppings</h3>
            <p>(validation text)</p>
          </div>
          <div class="form-group flex-row flex-wrap flex-wrap-2-column">
            {toppings.map((element_topping) => {
              return (
                <label class="width-50-percent">
                  <input
                    class="form-check-input"
                    name="toppings"
                    id="toppings"
                    type="checkbox"
                    value={element_topping}
                    onChange={cb_onChange}
                    checked={
                      Array.from(stateFormData.toppings).includes(
                        element_topping
                      )
                        ? true
                        : false
                    }
                  />
                  {element_topping}
                </label>
              );
            })}
          </div>
        </div>
        <div>
          <div class="form-group-header">
            <h3>Choice of Substitute</h3>
            <p>(validation text)</p>
          </div>
          <div class="form-group">
            <label class="flex-row">
              <input
                class="form-check-input width-30-percent"
                type="checkbox"
                name="gluten"
                id="gluten"
                onChange={cb_onChange}
                checked={stateFormData.gluten ? true : false}
              />
              <span>Glutent Free</span>
            </label>
          </div>
        </div>

        <div>
          <div class="form-group-header">
            <h3>Special Instructions</h3>
            <p>(validation text)</p>
          </div>
          <div class="form-group">
            <label class="width-90-percent">
              <input
                id="special-text"
                name="specialInstruction"
                type="text"
                placeholder="Anything else you'd like to add?"
                onChange={cb_onChange}
                class="form-control"
              ></input>
            </label>
          </div>
        </div>
        <div>
          <div class="form-group-header">
            <h3>(Final section)</h3>
            <p>(validation text)</p>
          </div>
          <div class="form-group flex-row">
            <label class="width-30-percent">
              <input
                id="quantity"
                name="quantity"
                type="number"
                min="0"
                max="100"
                onChange={cb_onChange}
                class="form-control"
              ></input>
            </label>
            <button id="order-button" class="width-70-percent">
              Add to Order
            </button>
          </div>
        </div>
      </form>
    </div>
  ); //end return statement
} //end function
