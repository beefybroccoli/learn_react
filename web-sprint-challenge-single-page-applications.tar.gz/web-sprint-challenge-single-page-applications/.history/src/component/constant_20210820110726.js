export const toppings = [
  "Pepperoni",
  "Sausage",
  "Canadian_Bacon",
  "Spicy_Italian_Sausage",
  "Grilled Chicken",
  "Onions",
  "Green_Pepper",
  "Diced_Tomatos",
  "Black_Olives",
  "Roasted_Garlic",
  "Artichoke_Hearts",
  "Three_Cheese",
  "Pineapple",
  "Extra_Cheese",
];

export const order_object = {
  name: stateFormData.name,
  size: stateFormData.size,
  sauce: "stateFormData.sauce",
  substitute: "",
  specialInstruction: "",
  quantity: "",
  Pepperoni: false,
  Sausage: false,
  Canadian_Bacon: false,
  Spicy_Italian_Sausage: false,
  Grilled_Chicken: false,
  Onions: false,
  Green_Pepper: false,
  Diced_Tomatos: false,
  Black_Olives: false,
  Roasted_Garlic: false,
  Artichoke_Hearts: false,
  Three_Cheese: false,
  Pineapple: false,
  Extra_Cheese: false,
};

export const sauces = [
  "Original Red",
  "Garlic Ranch",
  "BBQ Sauce",
  "Spinach Alfredo",
];

export const menu_items = [
  {
    title: "McDonald",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Pizza Hut",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Carl's Junior",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Dominos",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Walmart",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
  {
    title: "Target",
    image_src: "https://picsum.photos/200",
    image_alt: "(a random image)",
    description: "(random description)",
    dellievery_time: "30 to 40 mins",
    delievery_fee: "$25",
  },
];

export const pizzaSize = ["Select", "Small", "Medium", "Large", "Extra Large"];

/*
 {title:"",image_src:"" ,image_alt:"", description:"",dellievery_time:"",delievery_fee:""}
*/
