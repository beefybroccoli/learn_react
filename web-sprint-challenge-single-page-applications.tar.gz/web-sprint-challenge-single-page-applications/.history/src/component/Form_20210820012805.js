import React from "react";

export default function Form(props) {
  return (
    <div>
      <h2>Form Page</h2>
      <form>
        <label>
          Choice of Size
          <select>
            <option>Small</option>
            <option>Medium</option>
            <option>Large</option>
            <option>Extra Large</option>
          </select>
        </label>
        <label>
          Choice of Sauce
          <input type="radio" value="Original Red" />
          Original Red
          <input type="radio" value="Garlic Ranch" />
          Garlic Ranch
          <input type="radio" value="BBQ Sauce" />
          BBQ Sauce
          <input type="radio" value="Spinach Alfredo" />
          Spinach Alfredo
        </label>

        <p>Add Toppings</p>
        <label>
          <input type="checkbox" value="Pepperoni" />{" "}
        </label>
        <label>
          <input type="checkbox" value="Sausage" />
        </label>
        {/* <input type="checkbox" value="Canadian Bacon"/>
          <input type="checkbox" value="Spicy Italian Sausage"/>
          <input type="checkbox" value="Grilled Chicken"/>
          <input type="checkbox" value="Onions<"/>
          <input type="checkbox" value="Green Pepper"/>
          <input type="checkbox"value="Diced Tomatos"/>
          <input type="checkbox"value="Black Olives"/>
          <input type="checkbox"value="Roasted Garlic"/>
          <input type="checkbox"value="Artichoke Hearts"/>
          <input type="checkbox"value="Three Cheese"/>
          <input type="checkbox"value="Pineapple"/>
          <input type="checkbox"value="Extra Cheese"/> */}

        <label>
          Choice of Substitute
          <input type="checkbox"></input>
        </label>
        <label>
          Special Instructions
          <input type="text"></input>
        </label>
        <label>
          <input></input>
        </label>
        <button></button>
      </form>
    </div>
  );
}
