import React from "react";
import {toppings} from "./constant"

export default function Form(props) {
  return (
    <div>
      <h2>Form Page</h2>
      <form>
        <label>
          Choice of Size
          <select>
            <option>Small</option>
            <option>Medium</option>
            <option>Large</option>
            <option>Extra Large</option>
          </select>
        </label>
        <label>
          Choice of Sauce
          <input type="radio" value="Original Red" />
          Original Red
          <input type="radio" value="Garlic Ranch" />
          Garlic Ranch
          <input type="radio" value="BBQ Sauce" />
          BBQ Sauce
          <input type="radio" value="Spinach Alfredo" />
          Spinach Alfredo
        </label>

        <p>Add Toppings</p>
        {
            toppings.map()
        }

        <label>
          <input type="checkbox" value=" />
        </label>
        <label>
          <input type="checkbox" value="" />
        </label>
        {/* <input type="checkbox" value=""/>
          <input type="checkbox" value=""/>
          <input type="checkbox" value=""/>
          <input type="checkbox" value="<"/>
          <input type="checkbox" value=""/>
          <input type="checkbox"value=""/>
          <input type="checkbox"value=""/>
          <input type="checkbox"value=""/>
          <input type="checkbox"value=""/>
          <input type="checkbox"value=""/>
          <input type="checkbox"value=""/>
          <input type="checkbox"value=""/> */}

        <label>
          Choice of Substitute
          <input type="checkbox"></input>
        </label>
        <label>
          Special Instructions
          <input type="text"></input>
        </label>
        <label>
          <input></input>
        </label>
        <button></button>
      </form>
    </div>
  );
}
