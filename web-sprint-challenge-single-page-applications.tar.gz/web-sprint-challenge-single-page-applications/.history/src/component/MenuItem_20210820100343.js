import React from "react";

export default function MenuItem(props) {
  return (

    const [title, description,dellievery_time,delievery_fee, image_src, image_alt} = props.input_object;
    <div>
      <img
        src={props.input_object.image_src}
        alt={props.input_object.image_alt}
      />
      <h3>{props.input_object.title}</h3>
      <p>$ - {props.input_object.description}</p>
      <div class="flex-row">
        <p>${props.input_object.dellievery_time}</p>
        <p>${props.input_object.delievery_fee}</p>
      </div>
    </div>
  );
}
