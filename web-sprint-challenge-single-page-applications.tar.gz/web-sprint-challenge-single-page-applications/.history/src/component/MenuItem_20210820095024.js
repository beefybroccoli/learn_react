import React from "react";

export default function MenuItem(props){
    return (
        <div>
            <img src="" alt="a random image"/>
            <h3></h3>

        </div>
    );
}