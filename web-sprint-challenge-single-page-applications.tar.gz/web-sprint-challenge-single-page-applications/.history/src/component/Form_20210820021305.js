import React, { useState, useEffect } from "react";
import { toppings, sauces, pizzaSize } from "./constant";

export default function Form(props) {

const initial_state = {
    size:"", sauce:"", toppings:[], gluten:false, specialInstruction:"",quantity:""}
}

  const [stateFormData, set_FormData] = useState(initial_state);

  const cb_onChange = (event) => {};

  const cb_onSubmit = (event) => {};

  return (
    <div>
      <h2>Form Page</h2>
      <form>
        <div>
          <label>
            <h3>Choice of Size</h3>
            <br />
            <select
            id="size"
            name="size"
            >
            {
                pizzaSize.map(element => {
                    return (
                        <option value
                    );
                })
            }
              <option>Small</option>
              <option>Medium</option>
              <option>Large</option>
              <option>Extra Large</option>
            </select>
          </label>
        </div>
        <div>
          <h3> Choice of Sauce</h3>
          {sauces.map((sauce) => {
            return (
              <label>
                <input type="radio" value={sauce} />
                {sauce}
              </label>
            );
          })}
        </div>
        <div>
          <h3>Add Toppings</h3>
          {toppings.map((topping) => {
            return (
              <label>
                <input type="checkbox" value={topping} />
                {topping}
              </label>
            );
          })}
        </div>
        <div>
          <h3>Choice of Substitute</h3>
          <label>
            <input type="checkbox" aria-label="Toggle Button"></input>
          </label>
        </div>
        <div>
          <h3>Special Instructions</h3>
          <label>
            <input
              type="text"
              placeholder="Anything else you'd like to add?"
            ></input>
          </label>
        </div>
        <div>
          <h3>(Final section)</h3>
          <label>
            <input type="number" min="0" max="100"></input>
          </label>
          <button>Add to Order</button>
        </div>
      </form>
    </div>
  );
}
