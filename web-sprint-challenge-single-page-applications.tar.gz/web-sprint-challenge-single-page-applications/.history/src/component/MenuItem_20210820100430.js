import React from "react";

export default function MenuItem(props) {
  const [
    title,
    description,
    dellievery_time,
    delievery_fee,
    image_src,
    image_alt,
  ] = props.input_object;

  return (
    <div>
      <img src={image_src} alt={image_alt} />
      <h3>{title}</h3>
      <p>$ - {description}</p>
      <div class="flex-row">
        <p>${dellievery_time}</p>
        <p>${delievery_fee}</p>
      </div>
    </div>
  );
}
