import React from "react";

export default function Form(props) {
  return (
    <div>
      <h2>Form Page</h2>
      <form>
        <label>
          Choice of Size
          <select>
            <option>Small</option>
            <option>Medium</option>
            <option>Large</option>
            <option>Extra Large</option>
          </select>
        </label>
        <label>
          Choice of Sauce
          <input type="radio" value=""/>Original Red</input>
          <input type="radio">Garlic Ranch</input>
          <input type="radio">BBQ Sauce</input>
          <input type="radio">Spinach Alfredo</input>
        </label>
        <label>
          Add Toppings
          <input type="checkbox">Pepperoni</input>
          <input type="checkbox">Sausage</input>
          <input type="checkbox">Canadian Bacon</input>
          <input type="checkbox">Spicy Italian Sausage</input>
          <input type="checkbox">Grilled Chicken</input>
          <input type="checkbox">Onions</input>
          <input type="checkbox">Green Pepper</input>
          <input type="checkbox">Diced Tomatos</input>
          <input type="checkbox">Black Olives</input>
          <input type="checkbox">Roasted Garlic</input>
          <input type="checkbox">Artichoke Hearts</input>
          <input type="checkbox">Three Cheese</input>
          <input type="checkbox">Pineapple</input>
          <input type="checkbox">Extra Cheese</input>
        </label>
        <label>
          Choice of Substitute
          <input type="checkbox"></input>
        </label>
        <label>
          Special Instructions
          <input type="text"></input>
        </label>
        <label>
          <input></input>
        </label>
        <button></button>
      </form>
    </div>
  );
}
