export const toppings = ["Pepperoni", "Sausage","Canadian Bacon","Spicy Italian Sausage","Grilled Chicken","Onions"];
