import React from "react";

export default function MenuItem(props){
    return (
        <div>
            <img>
            <h3></h3>

        </div>
    );
}