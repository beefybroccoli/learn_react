import React from "react";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
import Home from "./component/Home";
import Form from "./component/Form";
import { Navbar, Nav, Container } from "react-bootstrap";

const App = () => {
  return (
    <>
      <h1>Lambda Eats</h1>

      <Navbar bg="dark" variant="dark" fixed="top">
        <Container>
          <Navbar.Brand href="/">LAMBDA EATS</Navbar.Brand>
          <Nav className="justify-content-end">
            <Nav.Link href="/pizza">Order</Nav.Link>
            <Nav.Link>Your Order</Nav.Link>
          </Nav>
        </Container>
      </Navbar>

      <Navbar>
        <Navbar.Header>
          <Navbar.Brand>
            <a href="/"></a>
          </Navbar.Brand>
        </Navbar.Header>
      </Navbar>

      <BrowserRouter>
        <Route path="/">
          <Home />
        </Route>

        <Route path="/pizza">
          <Form />
        </Route>
      </BrowserRouter>
    </>
  );
};
export default App;
