import React from "react";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
import Home from "./component/Home";
import Form from "./component/Form";
import { Navbar } from "react-bootstrap";
import { Container } from "css-declaration-sorter/node_modules/postcss";
import { NavLink } from "react-router-dom";
const App = () => {
  return (
    <>
      <h1>Lambda Eats</h1>

      <BrowserRouter>
        <Navbar bg="dark" variant="dark">
          <Container>
            <Navbar.Brand href="#home">LAMBDA EATS</Navbar.Brand>

            <Nav.Link to="/">Home</Nav.Link>
            <Nav.Link to="/pizza">Order Form</Nav.Link>
          </Container>
        </Navbar>

        <Route path="/">
          <Home />
        </Route>

        <Route path="/pizza">
          <Form />
        </Route>
      </BrowserRouter>
    </>
  );
};
export default App;
