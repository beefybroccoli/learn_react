import React, { useState, useEffect } from "react";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
import Home from "./component/Home";
import Form from "./component/Form";
import NavigationBar from "./component/NavigationBar";
import "bootstrap/dist/css/bootstrap.min.css";
import Page404 from "./component/404";
const App = () => {
  const [stateOrderRecord, set_OrderRecord] = useState([]);
  const array

  useEffect(() => {
    console.log(
      "Array.from(stateOrderRecord).length = ",
      Array.from(stateOrderRecord).length
    );
  }, [stateOrderRecord]);

  return (
    <main>
      <h1>Lambda Eats</h1>

      <NavigationBar />

      <BrowserRouter>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/pizza" component={Form} />
          <Route component={Page404} />
        </Switch>
      </BrowserRouter>
    </main>
  );
};
export default App;
