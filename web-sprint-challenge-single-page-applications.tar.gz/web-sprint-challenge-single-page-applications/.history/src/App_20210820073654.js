import React from "react";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
import Home from "./component/Home";
import Form from "./component/Form";
import { Navbar, Nav } from "react-bootstrap";
import { Container } from "css-declaration-sorter/node_modules/postcss";

const App = () => {
  return (
    <>
      <h1>Lambda Eats</h1>

      <BrowserRouter>
        <Navbar bg="dark" variant="dark">
          <Container>
            {/* <Navbar.Brand href="#">LAMBDA EATS</Navbar.Brand> */}

            {/* <NavLink to="/">Home</NavLink>
            <NavLink to="/pizza">Order Form</NavLink> */}
          </Container>
        </Navbar>

        <Route path="/">
          <Home />
        </Route>

        <Route path="/pizza">
          <Form />
        </Route>
      </BrowserRouter>
    </>
  );
};
export default App;
