import React from "react";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
import Home from "./component/Home";
import Form from "./component/Form";
import {}
const App = () => {
  return (
    <>
      <h1>Lambda Eats</h1>

      <BrowserRouter>
      <Navbar>

      </Navbar>
        <Link to="/">Home</Link>
        <Link to="/pizza">Order Form</Link>

        <Route path="/">
          <Home />
        </Route>

        <Route path="/pizza">
          <Form />
        </Route>
      </BrowserRouter>
    </>
  );
};
export default App;
