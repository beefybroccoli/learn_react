import React from "react";
import Home from "./component/Home";
import { BrowserRouter, Switch, Link, Route } from "react-router-dom";
const App = () => {
  return (
    <>
      <h1>Lambda Eats</h1>
      <Home />

      <BrowserRouter>
        <Link></Link>
        <Link></Link>

        <Route path></Route>

        <Route></Route>
      </BrowserRouter>
    </>
  );
};
export default App;
