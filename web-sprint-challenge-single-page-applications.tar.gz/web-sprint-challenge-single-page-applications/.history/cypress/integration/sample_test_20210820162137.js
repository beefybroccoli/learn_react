describe("sample test", () => {
  //   beforeEach(() => {
  //     cy.visit("localhost:3001");
  //   });

  it("visit the site", () => {
    cy.visit("https://localhost:3001/");
  });
});
