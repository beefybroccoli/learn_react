describe("sample test", () => {
  //   beforeEach(() => {
  //     cy.visit("localhost:3001");
  //   });

  it("visit the site", () => {
    cy.visit("http://localhost:3001");
  });

  cy.get("#")

});
