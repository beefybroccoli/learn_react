import { cypress as cy } from "cypress";

context("Action", ()=>{


});
describe("sample test", () => {
  beforeEach(() => {
    cy.visit("localhost:3001");
  });
});
