import cypress from "cypress";

describe("sample test", () => {
  beforeEach(() => {
    cy.visit("https://localhost:3001");
  });
});
