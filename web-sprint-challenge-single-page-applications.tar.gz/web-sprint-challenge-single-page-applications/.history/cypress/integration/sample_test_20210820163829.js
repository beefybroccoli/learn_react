const address = "http://localhost:3001";
/*

*/

describe("sample test", () => {
  //   beforeEach(() => {
  //     cy.visit("c");
  //   });

  it("visit the site", () => {
    cy.visit(address);
    cy.get("#order-pizza");
    // .contains("#order-pizza");
    // .click();
  });

  it("visit the site", () => {
    cy.visit(address + "/pizza");
    cy.get("#name-input");

    // cy.contains("#order-pizza");
    // cy.click();
  });
});
