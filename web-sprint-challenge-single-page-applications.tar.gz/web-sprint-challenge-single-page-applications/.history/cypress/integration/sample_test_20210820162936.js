const address = "http://localhost:3001";

describe("sample test", () => {
  //   beforeEach(() => {
  //     cy.visit("c");
  //   });

  it("visit the site", () => {
    cy.visit(address);
    cy.get("#order-pizza");
    cy.click();
  });

  //   cy.get("#order-pizza");
  //   cy.click();
});
