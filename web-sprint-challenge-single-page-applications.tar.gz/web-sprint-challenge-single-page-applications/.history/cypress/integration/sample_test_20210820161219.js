import cypress = require("cypress")

describe('sample test', () =>{

    beforeEach(()=>{
        cy.visit("https://localhost:3001");
    })



})