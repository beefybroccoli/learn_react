import cypress = require("cypress")

describe('sample test', () =>{

    beforeEach(()=>{
        cy.visit("https://")
    })



})