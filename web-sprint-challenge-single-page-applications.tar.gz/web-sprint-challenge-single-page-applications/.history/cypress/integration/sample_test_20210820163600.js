const address = "http://localhost:3001";

describe("sample test", () => {
  //   beforeEach(() => {
  //     cy.visit("c");
  //   });

  it("visit the site", () => {
    cy.visit(address);
    cy.get("#order-pizza");
    // .contains("#order-pizza");
    .click();
  });

  it("visit the site", () => {
    cy.visit(address);
    cy.get("#order-pizza");
    // cy.contains("#order-pizza");
    // cy.click();
  });

});
