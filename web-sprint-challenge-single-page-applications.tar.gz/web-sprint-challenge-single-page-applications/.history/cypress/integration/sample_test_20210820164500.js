const address = "http://localhost:3001";
/*
#pizza-form
#name-input
 #size-dropdown
 #special-text
 #order-button
*/

describe("sample test", () => {
  //   beforeEach(() => {
  //     cy.visit("c");
  //   });

  it("visit the site", () => {
    cy.visit(address);
    cy.get("#order-pizza");
    // .contains("#order-pizza");
    cy.click();
  });

  it("visit the site", () => {
    cy.visit(address + "/pizza");
    cy.get("#pizza-form");
    cy.get("#name-input");
    cy.get("#size-dropdown");

    // cy.contains("#order-pizza");
    // cy.click();
  });
});
